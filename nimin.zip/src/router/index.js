import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import { login, updateDetail, getUser } from '@/api/api.js'
import { getUrlCode } from '@/utils/index.js'
import { baselogin } from '@/api/api'
Vue.use(VueRouter)

const routes = [
  {
    path: '/home',
    name: 'Home',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: Home
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  {
    path: '/detail',
    name: 'Detail',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/Detail.vue')
  },
  {
    path: '/mine',
    name: 'Mine',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/Mine.vue')
  },
  {
    path: '/recyclesBin',
    name: 'RecyclesBin',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/RecyclesBin.vue')
  },
  {
    path: '/shield',
    name: 'shield',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/shield.vue')
  },
  {
    path: '/report',
    name: 'report',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/report.vue')
  },
  {
    path: '/record',
    name: 'Record',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/Record.vue')
  },
  {
    path: '/poster',
    name: 'poster',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/poster.vue')
  },
  {
    path: '/feedback',
    name: 'feedback',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/feedback.vue')
  },
  {
    path: '/',
    name: 'edit',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/Edit.vue')
  },
  {
    path: '/test',
    name: 'test',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/test.vue')
  },
  {
    path: '/FeedbackRecord',
    name: 'FeedbackRecord',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/FeedbackRecord.vue')
  },
  {
    path: '/FbrecordDetail',
    name: 'FbrecordDetail',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/FbrecordDetail.vue')
  },
  
  


]

const router = new VueRouter({
  mode: 'history',
  base: '/niming_letter/',
  routes
})

router.beforeEach((to, from, next) => {
  // 路由前置拦截，如果有query中有code,就调用登录接口换取session
  // 非静默授权获取用户信息
  // login(to.query.code).then(res => {
  //   localStorage.setItem('session', res.session)
  //   localStorage.setItem('user_id', res.user_id)
  //   next()
  // })
  console.log(to)

  // if (to.query.code) {
  //   login(to.query.code).then(res => {
  //     localStorage.setItem('session', res.session)
  //     localStorage.setItem('user_id', res.user_id)
  //     next()
  //   })
  // }
  // let session = localStorage.getItem('session')
  // if (!session) {
  //   var url = encodeURIComponent(window.location.href);
  //   var getCodeUrl = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx590ea386b2de4eb8&redirect_uri=${url}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect`;
  //   window.location.href = getCodeUrl;

  // } else {
  //   next()
  // }

  if (to.name === 'edit' || to.name === 'Home') {
    if (getUrlCode().code) {
      login(getUrlCode().code).then(result => {
        localStorage.setItem("session", result.data.session);
        localStorage.setItem("uid", result.data.uid);
       
      })
    }
  } else {
    if (getUrlCode().code) {
      baselogin(getUrlCode().code).then(result => {
        localStorage.setItem("session", result.data.session);
        localStorage.setItem("uid", result.data.uid);
      })
    }
  }
  next()

  // router.push('/about')
  // this.$rouet.push('/about')
  // if (to.name === 'Home') {
  //   // var getCodeUrl = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx590ea386b2de4eb8&redirect_uri=http%3a%2f%2fanonymous.lodidc.cn%2findex.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect`;
  //   // window.location.href = getCodeUrl;

  //   // if (to.query.code) {
  //   //   updateDetail(code).then(res=>{

  //   //   })
  //   // let session = localStorage.getItem('session')


  //    next()
  //   // }
  // } else {
  //   if (to.query.code) {

  //     // localStorage.setItem('',to.query.code)
  //     login(to.query.code).then(res => {
  //       localStorage.setItem('session', res.session)
  //       localStorage.setItem('user_id', res.user_id)
  //       next()
  //     })
  //   } else {
  //     next()
  //   }
  // }
 
})

export default router

