<template>
  <div>
    <wx-open-launch-weapp
      id="launch-btn"
      username="gh_330f9598db2c"
      path="pages/index/index"
    >
      <script type="text/wxtag-template">
        <style>.btn { padding: 12px }</style>
        <button class="btn">打开小程序</button>
      </script>
    </wx-open-launch-weapp>
  </div>
</template>

<script>
import wx from "weixin-js-sdk";
import { getConfig } from "@/api/api";
export default {
  mounted() {
    //获取jssdk配置
    let that = this;
    // let url = encodeURIComponent(window.location.href);
    that.session = localStorage.getItem("session");
    let data = {
      wechaturl: window.location.href,
      session: that.session,
    };
    getConfig(data).then((res) => {
      (that.appId = res.data.appId),
        wx.config({
          debug: true,
          appId: res.data.appId,
          timestamp: res.data.timestamp,
          nonceStr: res.data.nonceStr,
          signature: res.data.signature,
          jsApiList: ["chooseWXPay"],
          openTagList: ["wx-open-launch-weapp"],
        });
      wx.ready(function () {
        console.log("成功");
        console.log(that.launchWeapp);
        // config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，config是一个客户端的异步操作，所以如果需要在页面加载时就调用相关接口，则须把相关接口放在ready函数中调用来确保正确执行。对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中
      });
      wx.error(function (res) {
        console.log(res);
        // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名
      });
    });
  },
};
</script>

<style>
</style>