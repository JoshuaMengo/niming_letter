<template>
  <div class="edit_container">
    <div class="header">
      <div>TO {{ nickName }}:</div>
      <div><img src="../assets/headerLogo.png" /></div>
    </div>

    <div v-if="!isBlock">
      <div class="content">
        <textarea v-model="letterContent" placeholder="输入内容..." />
      </div>

      <div class="commit_btn" @click="isDialog = 'commit'">匿 名 发 送</div>
      <div class="commit_btn white_btn" @click="$router.push('/home')">
        我的信箱
      </div>
      <div class="tips">
        Tips：尊重好友，礼貌留言，恶意留言有可能被封禁账号哦
      </div>
    </div>

    <div v-else class="isBlock">
      <img src="../assets/v2_qk8z00.png" />
      <div>抱歉，您已被对方屏蔽，无法留言</div>
    </div>

    <div class="dialog" v-show="isDialog === 'commit'">
      <div class="dialog_content">
        <div>是否确定发送</div>
        <div>
          <div @click="isDialog = ''">修改</div>
          <div @click="commit()">发送</div>
        </div>
        <div>Tips：好友可通过访客记录知道您曾访问此信箱，有被猜中的概率哦</div>
      </div>
    </div>

    <div class="dialog" v-show="isDialog === 'success'" @click="isDialog = ''">
      <div class="successContent" @click.stop="">
        <div><img src="@/assets/_20201116173014.jpg" /></div>
        <div>长按关注，开启回复提醒，<br />点击菜单获取你的信箱链接</div>
      </div>
    </div>
  </div>
</template>

<script>
import { sendLetter, login, judgeBlock, getOther } from "@/api/api";
export default {
  data() {
    return {
      letterContent: "",
      isBlock: false,
      uid: "",
      isSuccess: false,
      isDialog: "",
      nickName: "",
    };
  },

  async mounted() {
    //获取路由中的id
    // console.log(this.$route)
    // console.log(1111111);
    this.uid = this.getUrlCode().id;
    // localStorage.setItem('toUid',this.getUrlCode().id)
    let session = localStorage.getItem("session");
    let code = this.getUrlCode().code;
    if (code) return;
    if (
      !localStorage.getItem("session") ||
      localStorage.getItem("session") === undefined
    ) {
      var url = encodeURIComponent(window.location.href);
      var getCodeUrl = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx590ea386b2de4eb8&redirect_uri=${url}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect`;
      window.location.href = getCodeUrl;
      // 如果缓存localStorage中没有微信openId，则需用code去后台获取
      // const res = await this.getUrlCode();
      // if (res.code) {
      //   const result = await login(res.code);
      //   await localStorage.setItem("session", result.data.session);
      //   await localStorage.setItem("user_id", result.data.user_id);
      // } else {
      //   var url = encodeURIComponent(window.location.href);
      //   var getCodeUrl = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx590ea386b2de4eb8&redirect_uri=${url}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect`;
      //   window.location.href = getCodeUrl;
      // }
    } else {
      // 别的业务逻辑
    }
  },

  created() {
    // emoji 后端测试用的
    // var url = encodeURIComponent(window.location.href);
    // var getCodeUrl = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${"wx590ea386b2de4eb8"}&redirect_uri=${"http%3a%2f%2fanonymous.lodidc.cn%2findex.html"}&response_type=code&scope=snsapi_base&state=1#wechat_redirect`;
    // window.location.href = getCodeUrl;
    this.getBlock();
    this.get_Order();
  },

  methods: {
    getBlock() {
      let data = {
        session: localStorage.getItem("session"),
        uid: this.getUrlCode().id,
      };
      judgeBlock(data).then((res) => {
        this.isBlock = res.data.is_block;
      });
    },

    get_Order() {
      let that = this;
      getOther({
        session: localStorage.getItem("session"),
        uid: this.getUrlCode().id,
      }).then((res) => {
        that.nickName = res.data.nickName;
      });
    },

    getUrlCode() {
      // 截取url中的code方法
      var url = location.search;
      console.log(url);
      this.winUrl = url;
      var theRequest = new Object();
      if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        var strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {
          theRequest[strs[i].split("=")[0]] = strs[i].split("=")[1];
        }
      }
      return theRequest;
    },

    commit() {
      if (this.letterContent + "" == "") {
        this.$Notify({ type: "warning", message: "请输入内容" });
      } else {
        let data = {
          content: this.letterContent,
          uid: this.getUrlCode().id,
          session: localStorage.getItem("session"),
        };
        sendLetter(data).then((res) => {
          if (res.err_code === 0) {
            this.isDialog = "success";
          }
        });
      }
    },
  },
};
</script>

<style lang="less" scoped>
.edit_container {
  //   height: 100vh !important;
  overflow-y: auto;
  // height: 77px;
  background: url("../assets/headerBg.jpg");
  padding: 0 25px 25px;
  color: white;
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  & > .header {
    display: flex;
    height: 77px;
    justify-content: space-between;
    align-items: center;
    & > div:first-child {
      color: rgba(255, 255, 255, 100);
      font-size: 16px;
    }
    img {
      width: 100px;
      height: 30px;
    }
  }
  .content {
    height: 390px;
    background: white;
    border-radius: 8px;
    padding: 20px;
    & > textarea {
      border: 0;
      height: 100%;
      width: 100%;
      color: black;
    }
  }
  .commit_btn {
    height: 42px;
    line-height: 42px;
    text-align: center;
    background-color: rgba(44, 44, 44, 100);
    border-radius: 4px;
    margin-top: 15px;
    font-weight: bold;
  }
  .white_btn {
    background: white;
    color: black;
  }
  .tips {
    color: rgba(255, 255, 255);
    font-size: 12px;
    text-align: center;
    opacity: 0.5;
    margin-top: 25px;
  }
  .isBlock {
    width: 225px;
    height: 225px;
    margin: 110px auto;
    text-align: center;
    img {
      width: 100%;
      height: 100%;
    }
  }
  & > .dialog {
    background: rgba(0, 0, 0, 0.65);
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 0 35px;
    img {
      width: 230px;
      height: 230px;
    }
    & > .successContent {
      background: none;
      color: white;
      & > div:nth-child(2) {
        margin-top: 10px;
        font-size: 14px;
        text-align: center;
        line-height: 20px;
      }
    }
    & > .dialog_content {
      color: black;
      background: white;
      padding: 40px 30px 20px;
      width: 205px;
      border-radius: 8px;
      display: flex;
      flex-direction: column;
      align-items: center;
      & > div:nth-child(1) {
        font-weight: bold;
        font-size: 16px;
      }
      & > div:nth-child(2) {
        display: flex;
        margin-top: 40px;
        & > div {
          width: 95px;
          height: 40px;
          line-height: 40px;
          text-align: center;
          border-radius: 5px;
          background-color: rgba(221, 221, 221, 100);
          margin: 0 5px;
        }
        & > div:nth-child(2) {
          background-color: rgba(16, 16, 16, 100);
          color: rgba(255, 255, 255, 100);
        }
      }
      & > div:nth-child(3) {
        margin: 14px 0;
        color: rgba(16, 16, 16);
        font-size: 12px;
        opacity: 0.4;
      }
    }
  }
}
</style>