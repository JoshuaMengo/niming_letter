<template>
  <div class="poster">
    <div class="goback"  @click="$router.go(-1)">
      <img src="../assets/wgoback.png" />
    </div>

    <div class="content" ref="imageWrapper">
      <img src="../assets/v2_qiyjex.png" />
      <div class="nickName">{{userInfo.nickName}}</div>
      <div class="avatar">

        <!-- <img src="http://anonymous.lodidc.cn/wechat_image/mmopen/vi_32/lXxWAQct5AqmJfgDrjibcbmgc3icEeCsr2wKArwEjE5rEe4UFEdUSMFI2M2u60wzDeSI3buhJ3YCbB7YicNyXT2cw/132"/> -->
        <img :src="userInfo.avatarUrl?userInfo.avatarUrl:''" crossOrigin="anonymous" />
      </div>
      <div id="qrcode_box" ref="code"  class="code"></div>
    </div>

    <div class="tips">长 按 保 存 海 报 并 分 享 到 朋 友 圈</div>

    <div @click="download()" class="create_porster">生成海报</div>

    <div class="dialog" v-show="dialogTableVisible" @click="dialogTableVisible=false">
      <img :src="downImg" @click.stop="" />
    </div>
  </div>
</template>

<script>
import QRCode from "qrcodejs2";
import html2canvas from "html2canvas";
export default {
  data() {
    return {
      downImg: "",
      dialogTableVisible: false,
      userInfo:{}
    };
  },
  // beforeCreate() {
  //   document
  //     .querySelector("body")
  //     .setAttribute("style", "background-color:#080808;height:100vh");
  // },
  mounted() {
    this.userInfo=JSON.parse(localStorage.getItem('userInfo'))
    this.Qrcode();
    console.log(this.userInfo)
  },

  methods: {
    
    Qrcode() {
      
      let w = String(parseInt(window.getComputedStyle(this.$refs.code).width)).replace('px','')
      let h = String(parseInt(window.getComputedStyle(this.$refs.code).height)).replace('px','')

      let qrcode = new QRCode("qrcode_box", {
        width: w, //二维码的宽度
        height: h, //二维码的高度
        text: "http://anonymous.lodidc.cn/niming_letter?id="+ this.userInfo.uid, // 二维码地址
        colorDark: "#000", //二维码颜色
        colorLight: "#fff", //二维码背景颜色
        size:'includes',
      });
    },
    
    toImage() {
      const opts = {
      useCORS: true,
       taintTest: true, // 在渲染前测试图片
        timeout: 500, // 加载延时
          backgroundColor: red,
		}
      html2canvas(this.$refs.imageWrapper,opts,{ allowTaint: true }).then((canvas) => {
        let dataURL = canvas.toDataURL("image/png");
        this.imgUrl = dataURL;
        if (this.imgUrl !== "") {
          this.dialogTableVisible = true;
        }
      });
    },

    download() {
      var this1 = this;
      setTimeout(function () {
        html2canvas(this1.$refs.imageWrapper, {
          backgroundColor: null,
        }).then((canvas) => {
          let dataURL = canvas.toDataURL("image/png");
          this1.downImg = dataURL;
          this1.dialogTableVisible = true;

          console.log(dataURL);
        });
      }, 500);
    },
  },
};
</script>

<style lang="less" scoped>

.poster {
  padding: 0 20px;
  // position:fixed;
  // top:0;
  // right:0;
  // left:0;
  // bottom:0;
  height:100%!important;
  background:#080808;
  .create_porster{
    margin:20px auto;
    color:black;
    background:white;
    width:80%!important;
    height:40px;
    line-height:40px;
    border-radius: 5px;
    text-align: center;
  }
  .goback { 
    display: inline-block;
    margin:20px 0 15px;
    img {
      width: 60px;
      height: 24px;
    }
  }
  & > .content {
    position: relative;
    &>img {
      width: 100%;
    }
    &>.avatar{
      position: absolute;
      border-radius: 50%;
      height:58px;
      width:58px;
      top:23px;
      left:30px;
      overflow: hidden;
      // z-index:999!important;
      &>img{
        height:100%;
        width:100%;
      }
    }
    &>.nickName{
      position: absolute;
      color:white;
      font-size:15px;
      left:30px;
      top:100px;
    }
    &>.code {
      height: 70px!important;
      width: 70px!important;
      position: absolute;
      left: 50%;
      top: 75.2%;
      transform: translateX(-50%);
    }
  }
  & > .tips {
    color: rgba(244, 245, 245, 100);
    text-align: center;
    font-size: 14px;
  }
  & > .dialog {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.65);
    display: flex;
    align-items: center;
    justify-content: center;
    img {
      width: 80%;
    }
    // & > div {
    //   position: absolute;
    //   left: 0;
    //   right: 0;
    //   top: 0;
    //   bottom: 0;
    //   height: 100%;
    //   width: 100%;
    // }
    // & > img {
    //   position: absolute;
    //   left: 50%;
    //   top: 50%;
    //   transform: translate(-50%, -50%);
    //   width: 80%;
    // }
  }
}
</style>