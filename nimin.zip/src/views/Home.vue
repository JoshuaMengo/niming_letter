<template>
  <div class="home">
    <div class="header">
      <div>
        <img :src="require('../assets/headerLogo.png')" />
      </div>
      <div class="avatar" @click="enterMine()">
        <div>我的</div>
        <div>
          <img :src="userInfo.avatarUrl" />
        </div>
      </div>
    </div>

    <div class="content">
      <div class="title">
        <div>信箱</div>
        <div class="tabbar">
          <div
            v-for="(item, index) in tabbarList ? tabbarList : []"
            :key="index"
            :class="checkTabbar == item.value ? 'active' : ''"
            @click="changeTabbar(item.value)"
          >
            {{ item.label }}
          </div>
        </div>
      </div>

      <div class="invitation_btn" @click="$router.push('/poster')">
        <img src="../assets/v2_qk8z4j.png" />
        邀请好友来信
      </div>

      <div v-show="dataList.length > 0">
        <van-list
          v-model="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
        >
          <!-- <van-cell v-for="item in list" :key="item" :title="item" /> -->
          <div
            class="list_item"
            v-for="(item, index) in dataList"
            :key="index"
            @click="enterDetail(item.lid)"
          >
            <div>
              {{ item.content }}
            </div>
            <div>
              <div>{{ item.create_time }}</div>
              <div>
                <span style="color: rgba(0, 0, 0); opacity: 0.5">
                  {{ item.has_read ? "已读" : "未读" }} &nbsp;</span
                >
                <span
                  style="color: #eb838d"
                  v-if="item.have_reply && !item.has_read_reply"
                  >新回复</span
                >
              </div>
            </div>

            <div v-if="!item.has_read" class="round"></div>
          </div>
        </van-list>
      </div>
      <div v-show="dataList.length <= 0" class="noContent">
        <img
          src="../assets/v2_qk8ywm.png"
          style="height: 135px; width: 135px"
        />
        <div>未收到来信</div>
      </div>
    </div>
  </div>
</template>

<script>
import { queryReceive, querySend, login, getUser } from "@/api/api";

export default {
  name: "Home",
  components: {
    // HelloWorld
  },
  data() {
    return {
      imgSrc: require("../assets/v2_qk8ywm.png"),
      dataList: [],
      tabbarList: [
        { label: "我收到的", value: 1 },
        { label: "我发出的", value: 2 },
      ],
      checkTabbar: 1,
      userInfo: {},
      listIndex: 0,
      loading: false,
      finished: false,
    };
  },
  beforeMount() {},

  async mounted() {
    //获取路由中的id
    // this.uid = this.$router.query.id
    let session = localStorage.getItem("session");
    let code = this.getUrlCode().code
    if(code) return
    if (
      !localStorage.getItem("session") ||
      localStorage.getItem("session") === undefined
    ) {
      var url = encodeURIComponent(window.location.href);
      var getCodeUrl = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx590ea386b2de4eb8&redirect_uri=${url}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect`;
      window.location.href = getCodeUrl;
      // 如果缓存localStorage中没有微信openId，则需用code去后台获取
      // const res = await this.getUrlCode();
      // if (res.code) {
      //   const result = await login(res.code);
      //   await localStorage.setItem("session", result.data.session);
      //   await localStorage.setItem("user_id", result.data.user_id);
      // } else {
      //   var url = encodeURIComponent(window.location.href);
      //   var getCodeUrl = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx590ea386b2de4eb8&redirect_uri=${url}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect`;
      //   window.location.href = getCodeUrl;
      // }
    } else {
      // 别的业务逻辑
    }

    this.userInfo = JSON.parse(localStorage.getItem("userInfo"));
    if (this.$route.query.index) {
      console.log(this.$route.query.index, "-----");
      this.checkTabbar = this.$route.query.index;
    }
  },


  async created() {
    // console.log(this.sendList, "#");
    if (this.$route.query.index) {
      this.$route.query.index == 1
        ? this.getReceivedList()
        : this.getSendList();
    } else {
      this.checkTabbar == 1 ? this.getReceivedList() : this.getSendList();
    }
  },
  methods: {
    async getReceivedList() {
      const res = await queryReceive({
        session: localStorage.getItem("session"),
        page_index: this.listIndex,
      });
      this.dataList = res.data.list;
    },

    async getSendList() {
      const res = await querySend({
        session: localStorage.getItem("session"),
        page_index: this.listIndex,
      });
      this.dataList = res.data.list;
    },

     getUrlCode() {
      // 截取url中的code方法
      var url = location.search;
      console.log(url);
      this.winUrl = url;
      var theRequest = new Object();
      if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        var strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {
          theRequest[strs[i].split("=")[0]] = strs[i].split("=")[1];
        }
      }
      return theRequest;
    },


    async onLoad() {
      this.listIndex += 1;
      const res =
        this.checkTabbar == 1
          ? await queryReceive({
              session: localStorage.getItem("session"),
              page_index: this.listIndex,
            })
          : await querySend({
              session: localStorage.getItem("session"),
              page_index: this.listIndex,
            });
      console.log(res);
      this.loading = false;
      if (res.data.list.length <= 0) {
        this.finished = true;
      } else {
        this.dataList = this.dataList.push(res.data.list);
      }
    },

    changeTabbar(index) {
      console.log(index);
      this.checkTabbar = index;
      this.listIndex = 0;
      index == 1 ? this.getReceivedList() : this.getSendList();
    },
    enterDetail(lid) {
      this.$router.push({
        path: "/detail", //这个path就是你在router/index.js里边配置的路径
        query: {
          lid: lid,
          is_receive: this.checkTabbar,
        },
      });
    },
    enterMine() {
      this.$router.push({
        path: "/mine", //这个path就是你在router/index.js里边配置的路径
      });
    },
  },
};
</script>

<style lang="less" scoped>
.home {
  flex: 1;
  background: #f4f5f5;
  .header {
    background: url("../assets/headerBg.jpg");
    height: 96px;
    padding: 50px 20px 0;
    display: flex;
    justify-content: space-between;
    color: white;
    font-size: 14px;
    & > div:first-child {
      height: 40px;
      line-height: 40px;
      & > img {
        margin-top: 5px;
        height: 30px;
        width: 100px;
      }
    }
    .avatar {
      display: flex;
      height: 40px;
      align-items: center;
      & > div:nth-child(2) {
        height: 38px;
        width: 38px;
        border-radius: 50%;
        border: 2px solid rgba(255, 255, 255, 100);
        margin-left: 8px;
        overflow: hidden;
        img {
          width: 100%;
          height: 100%;
        }
      }
    }
  }
  .content {
    border-radius: 20px 20px 0px 0px;
    background: #f4f5f5;
    transform: translatey(-20px);
    padding: 30px 20px;
    .title {
      display: flex;
      justify-content: space-between;
      align-items: center;
      & > div:first-child {
        color: rgba(16, 16, 16, 100);
        font-size: 20px;
        font-weight: bold;
      }
      .tabbar {
        display: flex;
        color: #c8c9c9;
        font-size: 14px;
        & > div {
          padding: 0 5px;
        }
        .active {
          font-weight: bold;
          color: #101010;
        }
      }
    }
    .invitation_btn {
      font-size: 16px;
      font-weight: bold;
      background: black;
      color: white;
      margin-top: 25px;
      height: 85px;
      display: flex;
      justify-content: center;
      border-radius: 10px;
      align-items: center;
      margin-bottom: 15px;
      & > img {
        height: 22px;
        width: 22px;
        margin-right: 5px;
      }
    }
    .list_item {
      background: white;
      padding: 20px;
      margin-bottom: 15px;
      border-radius: 10px;
      position: relative;
      & > div:first-child {
        font-size: 15px;
        color: rgba(61, 61, 61, 100);
      }
      & > div:nth-child(2) {
        display: flex;
        justify-content: space-between;
        margin-top: 15px;
        font-size: 13px;
        color: rgba(16, 16, 16, 50);
      }
      .round {
        height: 12px;
        width: 12px;
        background: #de2d3e;
        border-radius: 50%;
        position: absolute;
        right: 0;
        top: 0;
        transform: translate(25%, -25%);
      }
    }
  }
  .noContent {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 80px;
    font-size: 13px;
    color: #101010;
  }
}
</style>